RUn
python3 bulk_mailer.py recipients.txt Niran_Dev.pdf
